<html>
    <head>
        <title>Prova</title>
    </head>
    <body>
        <form method="post" action="regolazione.php">
            Seleziona l'ambiente da controllare:
            
            <select name="ambiente" id="ambiente">

            <?php
                $hostname = "localhost";
                $username = "root";
                $password = "";
                $dbname = "teleriscaldamento";
 
                // Apertura della connessione con il server MySQL
                $conn = mysqli_connect($hostname, $username, $password, $dbname);
                if (! $conn)
                {
                 die('Errore durante la connessione: ' . mysqli_connect_error());
                }
                echo "Connessione a MySQL effettuata con successo <BR/>";
                $stringa_query = "SELECT A.codice_ambiente FROM Ambienti A WHERE A.codice_appartamento=1";

				$ris= $conn->query($stringa_query);
                //echo $ris->num_rows;
                if ($ris->num_rows > 0){
					//Metti i dati (TIPICAMENTE in tabella)
					//Creo la tabella e metto la prima riga di intestazione (tipicamente i nomi delle colonne sono quelli della riga SELECT
					foreach($ris as $riga) {
                        echo "<option value=\"".$riga["codice_ambiente"]."\">".$riga["codice_ambiente"]."</option>";
                
						//echo $riga["codice_ambiente"]."<br/>";
                        //echo $riga;
					}
		
				} else {
					//Altrimenti stampo un messaggio di errore
					echo "Dati non presenti";
				}
                
                
                echo 'Hello Framework!';
            ?>

            </select><br/>


            Inserisci la temperatura minima desiderata: <input type="Text" id="tmin" name="tmin"/><br/>
            Inserisci la temperatura massima desiderata: <input type="Text" id="tmax" name="tmax"/><br/>
            Seleziona la stagione per la quale impostare la regolazione: 
            <select name="stagione" id="stagione">
                <option value="primavera">Primavera</option>
                <option value="estate">Estate</option>
                <option value="autunno">Autunno</option>
                <option value="inverno">Inverno</option>
            </select><br/>
            Seleziona la fascia oraria: 
            <select name="fascia" id="fascia">
                <option value="mattina">Mattino</option>
                <option value="pomeriggio">Pomeriggio</option>
                <option value="sera">Sera</option>
                <option value="notte">Notte</option>
            </select><br/> 
            <input type="submit" name="invia" value="OK">
            <input type="reset" name="cancella" value="Cancella">

            
         </form>
    </body>
</html>