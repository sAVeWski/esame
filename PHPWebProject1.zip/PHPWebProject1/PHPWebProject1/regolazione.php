<?php
	
	$ambiente=$_POST["ambiente"];
	$stagione=$_POST["stagione"];
	$fascia=$_POST["fascia"];
	$tmin=$_POST["tmin"];
	$tmax=$_POST["tmax"];

	$hostname = "localhost";
    $username = "root";
    $password = "";
    $dbname = "teleriscaldamento";
 
    // Apertura della connessione con il server MySQL
    $conn = mysqli_connect($hostname, $username, $password, $dbname);
    if (! $conn)
    {
        die('Errore durante la connessione: ' . mysqli_connect_error());
    }
    echo "Connessione a MySQL effettuata con successo <BR/>";
    $stringa_query = "INSERT INTO regolazioni (fascia_oraria, stagione, temperatura_minima, temperatura_massima, codice_ambiente) VALUES(\"$fascia\",\"$stagione\",$tmin,$tmax,$ambiente);";
    //echo $stringa_query."<BR/>";
	$ris= $conn->query($stringa_query);
	
	//Controllo che la query abbia ritornato qualche valore
	if ($ris==true){
		echo "L'inserimento &egrave; andato a buon fine!<BR/>";
		
	} else {
		//Altrimenti stampo un messaggio di errore
		echo "Errore durante l'inserimento.<BR/>";
	}

?>