﻿    function change(delta) {
            var value = parseInt(document.getElementById("temperatura").innerHTML);
            value += delta;
            if (value < 16) value = 16;
            if (value > 30) value = 30;
            document.getElementById("temperatura").innerHTML = value;
        }

        function downStagione(stagione) {
            var stagioni = ["primavera", "estate", "autunno", "inverno"];
            stagioni = stagioni.filter(function(item) {
                return item !== stagione
            })
            //document.write(stagioni);
            stagioni.forEach(downImage);
        }

        function downFascia(fascia) {
            var fasce = ["mattina", "pomeriggio", "sera", "notte"];
            fasce = fasce.filter(function (item) {
                return item !== fascia
            })
            //document.write(stagioni);
            fasce.forEach(downImage);
        }

        function downImage(item) {
        //document.write(item);
        document.getElementById(item).src = document.getElementById(item).src.replace("_up", "_down");
        }

        function cambiaStagione(stagione) {
            //document.write(document.getElementById(stagione).src);
            //alert(document.getElementById(stagione).src);
            //alert(document.getElementById(stagione).src.includes("_down"));
            if (document.getElementById(stagione).src.includes("_down")) {
        //alert(document.getElementById(stagione).src.replace("_down", "_up"));
        document.getElementById(stagione).src = document.getElementById(stagione).src.replace("_down", "_up");
                //alert(document.getElementById(stagione).src);
                downStagione(stagione);
            }
            else
            {
        document.getElementById(stagione).src.replace("_up", "_down");
            }
        }

        function cambiaFascia(fascia) {
            if (document.getElementById(fascia).src.includes("_down")) {
        //alert(document.getElementById(fascia).src.replace("_down", "_up"));
        document.getElementById(fascia).src = document.getElementById(fascia).src.replace("_down", "_up");
                //alert(document.getElementById(fascia).src);
                downFascia(fascia);
            }
            else {
        document.getElementById(fascia).src.replace("_up", "_down");
            }
        }

        function getRegolazione(tipo) {
        let regolazione = "";
            if (tipo == "fascia") {
                var fasce = ["mattina", "pomeriggio", "sera", "notte"];
                for (i = 0; i < 4; i++) {
                    var fascia = fasce[i];
                    var src = document.getElementById(fascia).src;
                    if (src.includes("_up")) regolazione = fascia;
                    //else regolazioni[i] = 0;
                    //alert("Fascia" + i + ": " + fascia + "=" + regolazioni[i]);
                }
            } else {//tipo == "stagione"
                var stagioni = ["primavera", "estate", "autunno", "inverno"];
                for (i = 0; i < 4; i++) {
                    var stagione = stagioni[i];
                    var src = document.getElementById(stagione).src;
                    if (src.includes("_up")) regolazione = stagione;
                    //else regolazioni[i] = 0;
                    //alert("Stagione" + i + ": " + stagione + "=" + regolazioni[i]);
                }
            }
            return regolazione;
        }

        function getTemperatura() {
            return document.getElementById("temperatura").innerHTML;
        }

        function getStagione(i) {
            var stagioni = ["primavera", "estate", "autunno", "inverno"];
            return stagioni[i];
        }

        function salva(idStanza, regolazioneFasce, regolazioneStagioni, temperatura) {
        //alert("Stagione: " + regolazioneStagioni + "\nFascia:" + regolazioneFasce+"\nTemperatura:"+ temperatura);

        $.ajax({

            url: "salvaregolazione.php?idstanza=" + idStanza + "&stagione=" + regolazioneStagioni + "&fascia=" + regolazioneFasce + "&temperatura=" + temperatura, //the page containing php script
            type: "GET", //request type
            //dataType: "json",
            //data: "{ domanda: "+domanda+", id_contributor: "+cid+"}",
            success: function (result) {
                alert(result);
                //document.getElementById("domande").innerHTML = domande+"<BR/>"+result+"<BR/>"+domanda;
                window.location.href = "regolastanza.html";
            },
            error: function (xhr, ajaxOptions, thrownError) {
                alert(xhr.status);
                alert(thrownError);
            }
        });

        }

        /*function debug(regolazioniFasce, regolazioniStagioni) {
            for (i = 0; i < 4; i++) {
        alert("Fascia" + i + "=" + regolazioniFasce[i]);
            }
            for (i = 0; i < 4; i++) {
        alert("Stagione" + i + "=" + regolazioniStagioni[i]);
            }
        }*/

        function salvaRegolazione() {
        let regolazioneFasce = getRegolazione("fascia");
            let regolazioneStagioni = getRegolazione("stagione");
            let temperatura = getTemperatura();
            //debug(regolazioniFasce, regolazioniStagioni);
            if (regolazioneFasce != "" && regolazioneStagioni != ""){
        //alert("SALVA!");
        salva(1, regolazioneFasce, regolazioneStagioni, temperatura);
			}
            else {
                if (regolazioneFasce == "" && regolazioneStagioni == "")
                    alert("Attenzione: occorre impostare la stagione e la fascia!");
                else if (regolazioneFasce == "")
                    alert("Attenzione: occorre impostare la fascia oraria!");
                else
                    alert("Attenzione: occorre impostare la stagione!");
            }
        }